package datamanagement;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.LinkedList;
import java.util.List;
import data.ParkingViolation;

public class ParkingViolationCSVReader implements ParkingViolationReader {
	private String fileName;
	private List<ParkingViolation> parkingViolationsList;
	
	public ParkingViolationCSVReader(String filename) {
		fileName = filename;
		parkingViolationsList = new LinkedList<>();
		
	}
	@Override
	public List<ParkingViolation> getViolations(){
		String row = null;
		try {
			FileReader fileReader = new FileReader(fileName);
			
			BufferedReader csvReader = new BufferedReader(fileReader);
			try {
				while ((row = csvReader.readLine())!=null) {
					String[] data = row.split(",");
					if (data.length!=7) {
						continue;
					}
					String date = data[0];
					int fine = Integer.parseInt(data[1]);
					String violation = data[2];
					String plate_id = data[3];
					String state = data[4];
					String ticket_number = data[5];
					String zip_code = data[6];
					parkingViolationsList.add(new ParkingViolation(ticket_number, plate_id, date, zip_code, violation, fine, state));
					
				}
				csvReader.close();
			}catch (NumberFormatException | IOException e) {
				System.out.println("File format invalid");
				System.exit(0);
			}
		}catch (FileNotFoundException e1) {
			System.out.println("File does not exist.");
			System.exit(0);
		}
		return parkingViolationsList;
	}

}
