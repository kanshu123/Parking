package datamanagement;
import java.util.List;

import data.*;

public interface ParkingViolationReader {
	public List<ParkingViolation> getViolations();

}
