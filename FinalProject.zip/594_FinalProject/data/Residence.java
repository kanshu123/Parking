package data;

public class Residence {
	private double livableArea;
	private double marketValue;
	private String zipCode;
	
	public Residence(double livableArea, double marketValue, String zipCode) {
		this.livableArea = livableArea;
		this.marketValue = marketValue;
		this.zipCode = zipCode;
	}
	public String toString() {
		return livableArea +"-" + marketValue + "-" + zipCode;
	}
	public double getLivableArea() {
		return livableArea;
	}
	public double getMarketValue() {
		return marketValue;
	}
	public String getZipCode() {
		return zipCode;
	}

}
